#include<windows.h>
//#include<stdio.h>
#include<conio.h>
#include<iostream.h>

int main()
{


	cout << "Elcome to C++ world ! " << endl;

	return 0;
}

