#include <windows.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include <conio.h>
#include <process.h>

// Secound Thread function
void ThreadProc(void *param);


// First thread 
int main()
{

	int n;
	int i;
	int val = 0;
	HANDLE handle;
	
	printf("\t Thread Demo\n");

	printf("Enter the number of threads : ");
	scanf("%d",&n);
	

	for(i=0;i<n;i++)
	{
		val = i+1;
		handle = (HANDLE) _beginthread( ThreadProc,0,&val); // create thread
		WaitForSingleObject(handle,INFINITE);
		
		
	}


	return 0;
}


void ThreadProc(void *param)
{
	
	int h=*((int*)param);
	printf("%d Thread is Running!\n",h);
	_endthread();

}

